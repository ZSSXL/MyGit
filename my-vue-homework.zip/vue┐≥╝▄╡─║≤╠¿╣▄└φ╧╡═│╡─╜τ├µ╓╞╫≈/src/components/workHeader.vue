<template>
	<header><h1>后台管理系统的界面</h1></header>
</template>

<script>
	export default{
		name:'work-header'
	};
</script>

<style scoped>
	header{
		position: absolute;
		left: 0;
		top: 0;
		right: 0;
		height: 72px;
		color: white;
		background: #ccc;
		border-radius: 10px;
		text-align: center;
	}
</style>
